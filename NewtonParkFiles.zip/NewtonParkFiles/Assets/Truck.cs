﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Truck : MonoBehaviour {
	public Camera cam;
	private bool jiggle;
	private bool unpause;
	// Use this for initialization
	void Start () {
		unpause = true;
		jiggle = false;
		cam.transform.position = transform.position + new Vector3 (0f, 0f, -50f);
	}
	
	// Update is called once per frame
	void Update () {
		if (!cam.GetComponent<CalcArea> ().pause){
			cam.transform.position = transform.position + new Vector3 (0f, 0f, -100f);
			if (!unpause) {
				StartCoroutine (CorrectSpawn ());
			}
		}
		unpause = !cam.GetComponent<CalcArea> ().pause;
		if (jiggle)
			transform.position += new Vector3 (0f, 0.5f, 0f);
		else
			transform.position -= new Vector3 (0f, 0.5f, 0f);
		jiggle = !jiggle;
		if (Input.GetKey (KeyCode.LeftArrow)) {
			//transform.position+=new Vector3(-5f, 0f, 0f);
			GetComponent<Rigidbody2D>().AddForce(new Vector3(-2000f,0f,0f), ForceMode2D.Impulse);
		}
		if(Input.GetKey(KeyCode.RightArrow)){
			//transform.position+=new Vector3(5f, 0f, 0f);
			GetComponent<Rigidbody2D>().AddForce(new Vector3(2000f,0f,0f), ForceMode2D.Impulse);
		}
	}
	public IEnumerator CorrectSpawn(){
		Color c = GetComponentInChildren<Text> ().color;
		c.a = 1;
		GetComponentInChildren<Text> ().color = c;
		while (GetComponentInChildren<Text> ().color.a > 0) {
			c.a-=0.05f;
			GetComponentInChildren<Text> ().color = c;
			yield return null;
		}
	}
}
