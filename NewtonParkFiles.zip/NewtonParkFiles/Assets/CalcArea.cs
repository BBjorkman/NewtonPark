﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CalcArea: MonoBehaviour{
	public int stage;
	public GameObject quizpanel;
	public Camera cam;
	public bool pause;
	private int[][] table;
	private float answer;
	private int number;
	private Vector3 t;
	private List<float> li;
	public void Start(){
		stage = 0;
		pause = false;
		li = new List<float> ();
		table = new int[55][];
		table [0] = new int[]{ 8, 0, 2 };
		table [1] = new int[]{ 8, 8, 2 };
		table [2] = new int[]{ 8, 0, 2 };
		table [10] = new int[]{ 8, 0, 2 };
		table [11] = new int[]{ 8, 9, 1 };
		table [12] = new int[]{ 9, 8, 1 };
		table [13] = new int[]{ 8, 0, 2 };
		table [20] = new int[]{ 5, 0, 1 };
		table [21] = new int[]{ 5, 8, 1 };
		table [22] = new int[]{ 8, 9, 1 };
		table [23] = new int[]{ 9, 8, 1 };
		table [24] = new int[]{ 8, 5, 1 };
		table [25] = new int[]{ 5, 0, 1 };
		table [50] = new int[]{ 6, 0, 1 };
		table [51] = new int[]{ 6, 4, 1 };
		table [52] = new int[]{ 4, 6, 1 };
		table [53] = new int[]{ 6, 0, 1 };
	}
	// Use this for initialization
	public void QuizTime(int code){
		pause = true;
		int level = code / 50;
		int refined = code / 10;
		int type = code;
		SetUpQuizPanel (code);
		cam.transform.position = new Vector3 (-225 + (refined * 100f), 5 - ((level % 4) * 200f), -50f);
		int h1 = table [type] [0], h2 = table [type] [1], b = table [type] [2];
		if (refined % 4 != 3) {
			quizpanel.transform.Find ("MultipleChoice").GetComponent<Text> ().text = "";
		}
		if (h2 != 0) {
			quizpanel.transform.Find ("Details").GetComponent<Text> ().text = "(Height 1: " + h1 + ", Height 2: " + h2 + ", Base: " + b + ")";
			quizpanel.transform.Find ("Text").GetComponent<Text> ().text = "Find the area of this trapezoid!";
		} else {
			quizpanel.transform.Find ("Details").GetComponent<Text> ().text = "(Height: " + h1 + ", Base: " + b + ")";
			quizpanel.transform.Find ("Text").GetComponent<Text> ().text = "Find the area of this triangle!";
		}
		if (refined > 4)
			refined -= 2;
		for (int i = 0; i < GameObject.Find ("ParabolaHusks").transform.GetChild (refined).childCount; i++) {
			if (i == type % 10) {
				GameObject.Find ("ParabolaHusks").transform.GetChild (refined).GetChild (i).gameObject.SetActive (true);
				number = type;
			}
			else
				GameObject.Find ("ParabolaHusks").transform.GetChild (refined).GetChild (i).gameObject.SetActive (false);
		}
		answer = (h1 + h2) / 2f * b;
		li.Add (answer);
	}
	public void CheckAnswer(string gues){
		bool stillgo = false;
		float guess = float.Parse (gues);
		if (guess +0.1f> answer&&guess-0.1f<answer) {
			quizpanel.SetActive (false);
			cam.transform.position = t;
			quizpanel.transform.parent.Find ("ParabolaPieces").GetChild (number / 10).GetChild (number % 10).gameObject.SetActive (false);
			for (int i = 0; i < quizpanel.transform.parent.Find ("ParabolaPieces").GetChild (number / 10).childCount; i++) {
				if (!quizpanel.transform.parent.Find ("ParabolaPieces").GetChild (number / 10).GetChild (i).gameObject.activeSelf)
					GameObject.Find ("ParabolaHusks").transform.GetChild (number / 10).GetChild (i).gameObject.SetActive (true);
				else {
					stillgo = true;
					GameObject.Find ("ParabolaHusks").transform.GetChild (number / 10).GetChild (i).gameObject.SetActive (false);
				}
			}
			if (li.Count == 0) {
				stage++;
				if (stage % 4 == 3) {
					SetUpQuizPanel (30);
					BossLevel ();
					return;
				}
				pause = false;
				return;
			}
			if (!stillgo) {
				SetUpQuizPanel (number);
				StartCoroutine (ShiftUp ());
				WrapUpZone ();
			} else
				pause = false;
		}
	}
	public IEnumerator ShiftUp(){
		cam.transform.position = quizpanel.transform.position - new Vector3 (75f, 75f, 50f);
		float follow = 0f;
		while(follow<75){
			cam.transform.Translate (new Vector3 (10f * Time.deltaTime, 10f * Time.deltaTime, 0f));
			follow += 10f * Time.deltaTime;
			yield return null;
		}
	}
	public void SetUpQuizPanel(int code){
		quizpanel.SetActive (true);
		quizpanel.transform.Find ("Panel").Find ("InputField").GetComponent<InputField> ().text = "";
		t = cam.transform.position;
		int level = code / 50;
		int refined = code % 50 / 10;
		quizpanel.transform.position = new Vector3 (-225 + (refined * 100f), 5 - ((level) * 150f), 0f);
	}
	public void WrapUpZone(){
		answer = 0;
		quizpanel.transform.Find ("Text").GetComponent<Text> ().text = "Based on your answers, what is this area?";
		string s = "Your answers were: ";
		if (stage == 3) {
			answer = 36;
			s += "32, 33, and 35. Slightly bigger each time!";
			quizpanel.transform.Find ("MultipleChoice").GetComponent<Text> ().text = "A. 34\nB. 36\nC. 40\nD. 42";
		} else {
			foreach (float i in li) {
				s += i + " + ";
				answer += i;
			}
		}
		quizpanel.transform.Find ("Details").GetComponent<Text> ().text = s.Substring (0, s.Length - 3);
		li = new List<float> ();
	}
	public void BossLevel(){
		StartCoroutine (ApproachBoss ());
	}
	public IEnumerator ApproachBoss(){
		WrapUpZone ();
		transform.position = Vector3.MoveTowards (transform.position, quizpanel.transform.position + new Vector3 (0f, 0f, -50f), 10f * Time.deltaTime);
		while (transform.position != quizpanel.transform.position + new Vector3 (0f, 0f, 50f)) {
			transform.position = Vector3.MoveTowards (transform.position, quizpanel.transform.position + new Vector3 (0f, 0f, -50f), 10f * Time.deltaTime);
			yield return null;
		}
		stage++;
	}
}
