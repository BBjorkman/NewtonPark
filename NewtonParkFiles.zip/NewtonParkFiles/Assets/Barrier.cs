﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Barrier : MonoBehaviour {
	public int killcode;
	void Update () {
		if (GameObject.Find ("Main Camera").GetComponent<CalcArea> ().stage == killcode)
			this.gameObject.SetActive (false);
	}
}
